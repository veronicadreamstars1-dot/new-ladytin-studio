# LadyTin Clean Story Studio

Clean Vercel/GitHub-ready version of LadyTin Story Studio.

## What this version does

- Opens directly. No email login. No password login. No Supabase auth blocker.
- Keeps the 4-stage workflow: Copy, Review Story, Assets & References, Generate.
- Saves current work in browser localStorage.
- Supports main assets, manual references, Pinterest snapshot/pin URL import, and editorial-direction-only fallback.
- Exports slide JSON, full story-set JSON, slide ZIPs, and full production ZIP.

## Deploy on Vercel

1. Create a new GitHub repository.
2. Upload these files.
3. Import the GitHub repo into Vercel.
4. Framework: Vite.
5. Build command: `npm run build`.
6. Output directory: `dist`.
7. Deploy.

No environment variables are required for this clean version.

## Local development

```bash
npm install
npm run dev
```
